// @ts-nocheck
import 'dotenv/config';
import { Pool } from 'pg';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(__dirname, '../../data');
let pool;
let initialization;

function schemaName() {
  // Tests always receive an isolated schema, even when a deployment .env is
  // loaded in the same process.
  const testFile = process.argv.some((argument) =>
    /(^|[\\/])test_[^\\/]+\.js$/i.test(argument),
  );
  const configured = process.env.NODE_ENV === 'test' || testFile
    ? (process.env.ZASMAOLT_TEST_DATABASE_SCHEMA || 'zasmaolt_test')
    : (process.env.ZASMAOLT_DATABASE_SCHEMA || 'zasmaolt');
  if (!/^[a-z_][a-z0-9_]*$/i.test(configured)) {
    throw new Error('ZASMAOLT_DATABASE_SCHEMA must be a PostgreSQL identifier.');
  }
  return configured;
}

function table(name) {
  return `"${schemaName()}"."${name}"`;
}

function getPool() {
  if (!pool) {
    const connectionString = String(process.env.DATABASE_URL || '').trim();
    if (!connectionString) throw new Error('DATABASE_URL is required for PostgreSQL persistence.');
    pool = new Pool({
      connectionString,
      max: Number(process.env.DATABASE_POOL_MAX) || 10,
      idleTimeoutMillis: 30_000,
      // Standalone Node test files do not own a Nest shutdown lifecycle.
      // Let their pool release the event loop as soon as each assertion ends.
      allowExitOnIdle: process.env.NODE_ENV === 'test' ||
        process.argv.some((argument) => /(^|[\\/])test_[^\\/]+\.js$/i.test(argument)),
    });
    pool.on('error', (error) => console.error('PostgreSQL idle client error:', error.message));
  }
  return pool;
}

async function query(text, params = []) {
  return getPool().query(text, params);
}

const napColumns = [
  'name', 'display_name', 'smartolt_account_id', 'smartolt_subdomain',
  'olt_id', 'olt_name', 'board', 'port', 'latitude', 'longitude',
  'total_clients', 'online_clients', 'offline_clients', 'status', 'clients',
];

function getNapStorageKey(nap = {}) {
  const account = String(nap.smartolt_account_id || nap.smartOltAccountId || 'default')
    .trim().toUpperCase() || 'DEFAULT';
  const olt = String(nap.olt_id || nap.oltId || nap.olt_name || nap.oltName || 'OLT')
    .trim().toUpperCase() || 'OLT';
  const name = String(nap.display_name || nap.name || '').trim().toUpperCase();
  return `${account}:${olt}:${name}`;
}

function napValues(nap = {}) {
  const displayName = String(nap.name || nap.display_name || '').trim();
  return [
    getNapStorageKey({ ...nap, display_name: displayName }),
    displayName,
    nap.smartolt_account_id || nap.smartOltAccountId || null,
    nap.smartolt_subdomain || nap.smartOltSubdomain || null,
    nap.olt_id || nap.oltId || null,
    nap.olt_name || nap.oltName || null,
    nap.board ?? null,
    nap.port ?? null,
    // Number(null) is 0. Preserve missing Smart OLT GPS as SQL NULL instead
    // of placing a NAP at the Gulf of Guinea (0,0).
    nap.latitude !== null && nap.latitude !== undefined && Number.isFinite(Number(nap.latitude))
      ? Number(nap.latitude) : null,
    nap.longitude !== null && nap.longitude !== undefined && Number.isFinite(Number(nap.longitude))
      ? Number(nap.longitude) : null,
    Number.isFinite(Number(nap.totalClients)) ? Number(nap.totalClients) : 0,
    Number.isFinite(Number(nap.onlineClients)) ? Number(nap.onlineClients) : 0,
    Number.isFinite(Number(nap.offlineClients)) ? Number(nap.offlineClients) : 0,
    nap.status || null,
    JSON.stringify(Array.isArray(nap.clients) ? nap.clients : []),
  ];
}

async function createSchema() {
  const schema = schemaName();
  await query(`CREATE SCHEMA IF NOT EXISTS "${schema}"`);
  await query(`
    CREATE TABLE IF NOT EXISTS ${table('naps')} (
      name TEXT PRIMARY KEY, display_name TEXT NOT NULL, smartolt_account_id TEXT,
      smartolt_subdomain TEXT, olt_id TEXT, olt_name TEXT, board TEXT, port TEXT,
      latitude DOUBLE PRECISION, longitude DOUBLE PRECISION,
      total_clients INTEGER NOT NULL DEFAULT 0, online_clients INTEGER NOT NULL DEFAULT 0,
      offline_clients INTEGER NOT NULL DEFAULT 0, status TEXT,
      clients JSONB NOT NULL DEFAULT '[]'::jsonb
    )`);
  await query(`
    CREATE TABLE IF NOT EXISTS ${table('status_history')} (
      id TEXT PRIMARY KEY, timestamp TEXT, "formattedTime" TEXT, "eventTime" TEXT,
      sn TEXT, "onuName" TEXT, "napName" TEXT, "previousStatus" TEXT,
      "newStatus" TEXT, "napStatus" TEXT, "failureType" TEXT, "failureLabel" TEXT,
      reason TEXT, resolved BOOLEAN NOT NULL DEFAULT FALSE, "resolvedAt" TEXT,
      "oltName" TEXT, board TEXT, port TEXT, latitude DOUBLE PRECISION, longitude DOUBLE PRECISION
    )`);
  await query(`
    CREATE TABLE IF NOT EXISTS ${table('optical_history')} (
      id BIGSERIAL PRIMARY KEY, sn TEXT NOT NULL, rx_power DOUBLE PRECISION,
      tx_power DOUBLE PRECISION, temperature DOUBLE PRECISION, voltage DOUBLE PRECISION,
      bias_current DOUBLE PRECISION, timestamp TEXT NOT NULL
    )`);
  await query(`
    CREATE TABLE IF NOT EXISTS ${table('operational_alert_state')} (
      "alertKey" TEXT PRIMARY KEY, "firstDetectedAt" BIGINT,
      "lastSentAt" BIGINT NOT NULL, "blockedAt" BIGINT
    )`);
  await query(`
    CREATE TABLE IF NOT EXISTS ${table('app_meta')} (
      key TEXT PRIMARY KEY, value TEXT NOT NULL
    )`);
  await query(`
    CREATE TABLE IF NOT EXISTS ${table('omni_event_outbox')} (
      id BIGSERIAL PRIMARY KEY, "eventId" TEXT NOT NULL UNIQUE,
      payload JSONB NOT NULL, "createdAt" BIGINT NOT NULL
    )`);
  await Promise.all([
    query(`CREATE INDEX IF NOT EXISTS idx_zasmaolt_history_timestamp ON ${table('status_history')} (timestamp DESC)`),
    query(`CREATE INDEX IF NOT EXISTS idx_zasmaolt_history_resolved_timestamp ON ${table('status_history')} (resolved, timestamp DESC)`),
    query(`CREATE INDEX IF NOT EXISTS idx_zasmaolt_optical_sn_timestamp ON ${table('optical_history')} (sn, timestamp DESC)`),
    query(`CREATE INDEX IF NOT EXISTS idx_zasmaolt_outbox_created_at ON ${table('omni_event_outbox')} ("createdAt")`),
  ]);
}

async function ensureInitialized() {
  if (!initialization) {
    initialization = createSchema().catch((error) => {
      initialization = undefined;
      throw error;
    });
  }
  await initialization;
}

export async function initDb() {
  await ensureInitialized();
  await migrateLegacyHistoryFile();
  const purge = await query(
    `DELETE FROM ${table('status_history')} WHERE "napName" = $1 OR UPPER(COALESCE(sn, '')) LIKE $2`,
    ['NAP-ZABBIX-1', 'FHTTZAB%'],
  );
  if (purge.rowCount) console.log(`🧹 Removed ${purge.rowCount} obsolete integration-test history record(s).`);
  console.log(`📡 PostgreSQL connected (schema: ${schemaName()}).`);
  return { migratedNapStorageKeys: 0 };
}

export async function closeDb() {
  if (pool) {
    await pool.end();
    pool = undefined;
    initialization = undefined;
  }
}

export function getPostgresPool() {
  return getPool();
}

export async function dbGetAppMeta(key) {
  await ensureInitialized();
  const result = await query(`SELECT value FROM ${table('app_meta')} WHERE key = $1`, [key]);
  return result.rows[0]?.value ?? null;
}

export async function dbSetAppMeta(key, value) {
  await ensureInitialized();
  await query(
    `INSERT INTO ${table('app_meta')} (key, value) VALUES ($1, $2)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value`,
    [key, String(value)],
  );
}

export async function dbQueueOmniEvent(event) {
  await ensureInitialized();
  const eventId = String(event?.eventId || '').trim();
  if (!eventId) throw new Error('Cannot queue an OmniSentinel event without eventId');
  const result = await query(
    `INSERT INTO ${table('omni_event_outbox')} ("eventId", payload, "createdAt")
     VALUES ($1, $2::jsonb, $3) ON CONFLICT ("eventId") DO NOTHING`,
    [eventId, JSON.stringify(event), Date.now()],
  );
  return { queued: result.rowCount > 0 };
}

export async function dbListOmniEvents(afterId = 0, limit = 100) {
  await ensureInitialized();
  const cursor = Number.isInteger(Number(afterId)) && Number(afterId) >= 0 ? Number(afterId) : 0;
  const pageSize = Math.min(Math.max(Number.parseInt(limit, 10) || 100, 1), 200);
  const result = await query(
    `SELECT id, payload FROM ${table('omni_event_outbox')} WHERE id > $1 ORDER BY id ASC LIMIT $2`,
    [cursor, pageSize],
  );
  return result.rows.flatMap((row) => {
    const event = typeof row.payload === 'string' ? safeJson(row.payload) : row.payload;
    return event && typeof event === 'object' ? [{ cursor: Number(row.id), event }] : [];
  });
}

export async function dbGetOmniEventCursor() {
  await ensureInitialized();
  const result = await query(
    `SELECT COALESCE(MAX(id), 0) AS "latestCursor" FROM ${table('omni_event_outbox')}`,
  );
  return Number(result.rows[0]?.latestCursor || 0);
}

export async function dbPruneOmniEvents(retentionDays = 7) {
  await ensureInitialized();
  const days = Math.min(Math.max(Number(retentionDays) || 7, 1), 30);
  await query(
    `DELETE FROM ${table('omni_event_outbox')} WHERE "createdAt" < $1`,
    [Date.now() - days * 24 * 60 * 60 * 1000],
  );
}

export async function dbGetAllNaps() {
  try {
    await ensureInitialized();
    const result = await query(`SELECT * FROM ${table('naps')}`);
    return result.rows.map((row) => ({
      ...row,
      name: row.display_name || row.name,
      totalClients: row.total_clients,
      onlineClients: row.online_clients,
      offlineClients: row.offline_clients,
      clients: Array.isArray(row.clients) ? row.clients : safeJson(row.clients) || [],
    }));
  } catch (error) {
    console.error('dbGetAllNaps error:', error.message);
    return [];
  }
}

export async function dbSaveNap(nap) {
  await ensureInitialized();
  const columns = napColumns.join(', ');
  const placeholders = napColumns.map((_, index) => `$${index + 1}`).join(', ');
  const updates = napColumns.filter((column) => column !== 'name')
    .map((column) => `${column} = EXCLUDED.${column}`).join(', ');
  await query(
    `INSERT INTO ${table('naps')} (${columns}) VALUES (${placeholders})
     ON CONFLICT (name) DO UPDATE SET ${updates}`,
    napValues(nap),
  );
}

export async function dbReplaceNaps(naps = []) {
  await ensureInitialized();
  const client = await getPool().connect();
  try {
    await client.query('BEGIN');
    await client.query(`DELETE FROM ${table('naps')}`);
    const columns = napColumns.join(', ');
    const placeholders = napColumns.map((_, index) => `$${index + 1}`).join(', ');
    for (const nap of Array.isArray(naps) ? naps : []) {
      await client.query(`INSERT INTO ${table('naps')} (${columns}) VALUES (${placeholders})`, napValues(nap));
    }
    await client.query('COMMIT');
    return Array.isArray(naps) ? naps.length : 0;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

const historyColumns = [
  'id', 'timestamp', '"formattedTime"', '"eventTime"', 'sn', '"onuName"', '"napName"',
  '"previousStatus"', '"newStatus"', '"napStatus"', '"failureType"', '"failureLabel"',
  'reason', 'resolved', '"resolvedAt"', '"oltName"', 'board', 'port', 'latitude', 'longitude',
];

function historyValues(item = {}) {
  return [
    item.id, item.timestamp || null, item.formattedTime || null, item.eventTime || null,
    item.sn || null, item.onuName || null, item.napName || null,
    item.previousStatus || null, item.newStatus || null, item.napStatus || null,
    item.failureType || null, item.failureLabel || null, item.reason || null,
    Boolean(item.resolved), item.resolvedAt || null, item.oltName || null,
    item.board ?? null, item.port ?? null, item.latitude ?? null, item.longitude ?? null,
  ];
}

function historyRecord(row) {
  return { ...row, resolved: Boolean(row.resolved) };
}

export async function dbGetStatusHistory(limit = 100, filter = 'all') {
  try {
    await ensureInitialized();
    const where = filter === 'pending' ? 'WHERE resolved = FALSE'
      : filter === 'resolved' ? 'WHERE resolved = TRUE' : '';
    const result = await query(
      `SELECT * FROM ${table('status_history')} ${where} ORDER BY timestamp DESC LIMIT $1`,
      [Math.max(1, Number(limit) || 100)],
    );
    return result.rows.map(historyRecord);
  } catch (error) {
    console.error('dbGetStatusHistory error:', error.message);
    return [];
  }
}

export async function dbSaveHistoryItem(item) {
  await ensureInitialized();
  const placeholders = historyColumns.map((_, index) => `$${index + 1}`).join(', ');
  const updates = historyColumns.filter((column) => column !== 'id')
    .map((column) => `${column} = EXCLUDED.${column}`).join(', ');
  await query(
    `INSERT INTO ${table('status_history')} (${historyColumns.join(', ')}) VALUES (${placeholders})
     ON CONFLICT (id) DO UPDATE SET ${updates}`,
    historyValues(item),
  );
}

export async function dbDeleteHistoryItem(id) {
  await ensureInitialized();
  const result = await query(`DELETE FROM ${table('status_history')} WHERE id = $1 RETURNING *`, [id]);
  return result.rows[0] ? historyRecord(result.rows[0]) : null;
}

export async function dbClearHistory(mode = 'all') {
  await ensureInitialized();
  const where = mode === 'resolved' ? 'WHERE resolved = TRUE' : '';
  await query(`DELETE FROM ${table('status_history')} ${where}`);
  const result = await query(`SELECT * FROM ${table('status_history')} ORDER BY timestamp DESC`);
  return result.rows.map(historyRecord);
}

export async function dbResolveHistoryItem(id, resolvedAt) {
  await ensureInitialized();
  const result = await query(
    `UPDATE ${table('status_history')} SET resolved = TRUE, "resolvedAt" = $1 WHERE id = $2 RETURNING *`,
    [resolvedAt, id],
  );
  return result.rows[0] ? historyRecord(result.rows[0]) : null;
}

export async function dbGetOperationalAlertStates() {
  try {
    await ensureInitialized();
    const result = await query(
      `SELECT "alertKey", "firstDetectedAt", "lastSentAt", "blockedAt" FROM ${table('operational_alert_state')}`,
    );
    return result.rows;
  } catch (error) {
    console.error('dbGetOperationalAlertStates error:', error.message);
    return [];
  }
}

export async function dbSaveOperationalAlertState(alertKey, state = Date.now()) {
  await ensureInitialized();
  const legacyTimestamp = Number(state);
  const firstDetectedAt = Number(state?.firstDetectedAt) || legacyTimestamp || Date.now();
  const lastSentAt = Number(state?.lastSentAt) || legacyTimestamp || firstDetectedAt;
  const blockedAt = Number(state?.blockedAt) || null;
  await query(
    `INSERT INTO ${table('operational_alert_state')} ("alertKey", "firstDetectedAt", "lastSentAt", "blockedAt")
     VALUES ($1, $2, $3, $4) ON CONFLICT ("alertKey") DO UPDATE SET
       "firstDetectedAt" = EXCLUDED."firstDetectedAt", "lastSentAt" = EXCLUDED."lastSentAt",
       "blockedAt" = EXCLUDED."blockedAt"`,
    [alertKey, firstDetectedAt, lastSentAt, blockedAt],
  );
}

export async function dbDeleteOperationalAlertState(alertKey) {
  await ensureInitialized();
  await query(`DELETE FROM ${table('operational_alert_state')} WHERE "alertKey" = $1`, [alertKey]);
}

export async function dbSaveOpticalRecord(sn, rx, tx, temp, volt, bias) {
  await ensureInitialized();
  await query(
    `INSERT INTO ${table('optical_history')} (sn, rx_power, tx_power, temperature, voltage, bias_current, timestamp)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [
      String(sn || '').toUpperCase(),
      Number.isFinite(rx) ? rx : null, Number.isFinite(tx) ? tx : null,
      Number.isFinite(temp) ? temp : null, Number.isFinite(volt) ? volt : null,
      Number.isFinite(bias) ? bias : null, new Date().toISOString(),
    ],
  );
}

export async function dbGetOpticalHistory(sn, limit = 20) {
  try {
    await ensureInitialized();
    const result = await query(
      `SELECT * FROM ${table('optical_history')} WHERE sn = $1 ORDER BY timestamp DESC LIMIT $2`,
      [String(sn || '').toUpperCase(), Math.max(1, Number(limit) || 20)],
    );
    return result.rows.reverse();
  } catch (error) {
    console.error(`dbGetOpticalHistory error for ${sn}:`, error.message);
    return [];
  }
}

async function migrateLegacyHistoryFile() {
  const marker = 'legacy_status_history_json_v1_processed';
  if (await dbGetAppMeta(marker)) return;
  const historyFile = path.join(dataDir, 'status_history.json');
  if (fs.existsSync(historyFile)) {
    try {
      const data = JSON.parse(fs.readFileSync(historyFile, 'utf8'));
      for (const item of Array.isArray(data) ? data : []) {
        if (item?.napName === 'NAP-ZABBIX-1' || String(item?.sn || '').toUpperCase().startsWith('FHTTZAB')) continue;
        if (item?.id) await dbSaveHistoryItem(item);
      }
    } catch (error) {
      console.error('Could not import legacy status history JSON:', error.message);
    }
  }
  await dbSetAppMeta(marker, new Date().toISOString());
}

function safeJson(value) {
  try {
    return typeof value === 'string' ? JSON.parse(value) : value;
  } catch {
    return null;
  }
}
