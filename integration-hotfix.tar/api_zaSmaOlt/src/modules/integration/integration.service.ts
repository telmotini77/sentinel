import { Injectable } from '@nestjs/common';
import { getCachedNaps } from '../../services/cache.js';
import { dbGetOmniEventCursor, dbListOmniEvents } from '../../services/db.js';
import { getScannerStatus } from '../../services/scanner.js';
import {
  mapCustomer,
  mapNapSummary,
  matchesNap,
  normalize,
  positiveInteger,
} from '../../services/omniSentinelService.js';

/**
 * Application service for the read-only api_zaSmaOlt -> OmniSentinel contract.
 * Keeping data shaping here leaves controllers responsible only for HTTP.
 */
export class IntegrationService {
  health() {
    const naps = getCachedNaps();
    return { status: 'ok', source: 'api_zaSmaOlt', cachedNaps: naps.length };
  }

  async events(query: Record<string, any> = {}) {
    const parsedAfter = Number.parseInt(String(query.after || '0'), 10);
    const after = Number.isInteger(parsedAfter) && parsedAfter >= 0 ? parsedAfter : 0;
    const limit = positiveInteger(query.limit, 100, 200);
    const [data, latestCursor] = await Promise.all([
      dbListOmniEvents(after, limit),
      dbGetOmniEventCursor(),
    ]);
    const nextCursor = data.length ? data[data.length - 1].cursor : after;
    return { data, nextCursor, hasMore: data.length === limit, latestCursor };
  }

  inventory(query: Record<string, any> = {}) {
    const page = positiveInteger(query.page, 1, 1_000_000);
    const limit = positiveInteger(query.limit, 50, 200);
    const search = normalize(query.search);
    const oltId = normalize(query.oltId);
    const requestedStatus = String(query.status || '').trim().toUpperCase();
    const cachedNaps = getCachedNaps();
    const items = cachedNaps
      .map(mapNapSummary)
      .filter((nap) => {
        const searchable = `${nap.name} ${nap.oltId} ${nap.oltName}`.toLowerCase();
        return (!search || searchable.includes(search)) &&
          (!oltId || normalize(nap.oltId) === oltId || normalize(nap.oltName) === oltId) &&
          (!requestedStatus || nap.status === requestedStatus);
      })
      .sort((left, right) => left.name.localeCompare(right.name, 'es'));
    const scanner = getScannerStatus();
    const start = (page - 1) * limit;

    return {
      data: items.slice(start, start + limit),
      total: items.length,
      page,
      limit,
      source: 'SMARTOLT_CACHE',
      cachedNaps: cachedNaps.length,
      refreshedAt: scanner.lastCacheSyncAt || scanner.lastSuccessAt || null,
      isStale: Boolean(scanner.lastError),
    };
  }

  impact(oltId, board, pon) {
    const naps = getCachedNaps().filter((nap) => matchesNap(nap, oltId, board, pon));
    const customers = naps.flatMap((nap) =>
      (nap.clients || []).map((client) => mapCustomer(client, nap)).filter(Boolean),
    );
    return {
      data: customers,
      total: customers.length,
      scope: { oltId, board: Number(board), pon: Number(pon) },
    };
  }
}

Injectable()(IntegrationService);
